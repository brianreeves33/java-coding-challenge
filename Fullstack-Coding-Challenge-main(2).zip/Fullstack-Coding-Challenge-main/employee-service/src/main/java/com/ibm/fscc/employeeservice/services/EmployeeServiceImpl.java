package com.ibm.fscc.employeeservice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.fscc.employeeservice.data.EmployeeEntity;
import com.ibm.fscc.employeeservice.repository.EmployeeRepository;
import com.ibm.fscc.employeeservice.shared.EmployeeDto;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;


    @Override
    public List<EmployeeEntity> getAllEmployees() {
        return (List<EmployeeEntity>) employeeRepository.findAll();
    }

    @Override
    public EmployeeEntity addNewEmployee(EmployeeDto employeeData) {

        EmployeeEntity entity = new EmployeeEntity();

        entity.addUser(employeeData);

        return employeeRepository.save(entity);

    }

    @Override
    public boolean doesEmployeeExistByEmail(String email) {
        return employeeRepository.existsByEmail(email);
    }

    @Override
    public Optional<EmployeeEntity> findByEmail(String email) {
        return employeeRepository.findByEmail(email);
    }

    @Override
    public EmployeeEntity updateEmployee(EmployeeEntity updatedEmployee) {
        return employeeRepository.save(updatedEmployee);
    }

    @Override
    public void removeEmployee(EmployeeEntity employee) {
        employeeRepository.delete(employee);
    }


}
