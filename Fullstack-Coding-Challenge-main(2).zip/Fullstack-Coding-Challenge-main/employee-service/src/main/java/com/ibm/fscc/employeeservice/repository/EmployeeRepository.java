package com.ibm.fscc.employeeservice.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.ibm.fscc.employeeservice.data.EmployeeEntity;


public interface EmployeeRepository
                extends CrudRepository<EmployeeEntity, Long> {

        boolean existsByEmail(String email);

        Optional<EmployeeEntity> findByEmail(String email);

         void delete(EmployeeEntity employee);


}
