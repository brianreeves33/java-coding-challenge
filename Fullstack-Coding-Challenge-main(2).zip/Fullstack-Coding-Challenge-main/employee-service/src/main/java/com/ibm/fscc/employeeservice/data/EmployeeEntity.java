package com.ibm.fscc.employeeservice.data;

import java.util.UUID;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import com.ibm.fscc.employeeservice.shared.EmployeeDto;

@Entity
@Table(name = "employee")
public class EmployeeEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; 
	private String userId;
	private String firstName;
	private String lastName;
	private String address;
	private String state;
	private String zip;
	private String cellPhone;
	private String homePhone;
	private String email;

	public EmployeeEntity() {
		this.userId = UUID.randomUUID().toString();
	}

	public void updateFields(EmployeeDto dto) {
		this.firstName = dto.getFirstName();
		this.lastName = dto.getLastName();
		this.address = dto.getAddress();
		this.state = dto.getState();
		this.zip = dto.getZip();
		this.cellPhone = dto.getCellPhone();
		this.homePhone = dto.getHomePhone();

	}

	public void addUser(EmployeeDto dto) {
		this.firstName = dto.getFirstName();
		this.lastName = dto.getLastName();
		this.address = dto.getAddress();
		this.state = dto.getState();
		this.zip = dto.getZip();
		this.cellPhone = dto.getCellPhone();
		this.homePhone = dto.getHomePhone();
		this.email = dto.getEmail();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCellPhone() {
		return cellPhone;
	}

	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	public String getHomePhone() {
		return homePhone;
	}

	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
