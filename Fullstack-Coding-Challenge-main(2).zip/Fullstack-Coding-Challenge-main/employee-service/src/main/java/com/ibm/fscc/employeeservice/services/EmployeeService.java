package com.ibm.fscc.employeeservice.services;

import java.util.List;
import java.util.Optional;

import com.ibm.fscc.employeeservice.data.EmployeeEntity;
import com.ibm.fscc.employeeservice.shared.EmployeeDto;

public interface EmployeeService {

    public List<EmployeeEntity> getAllEmployees();

    public EmployeeEntity updateEmployee(EmployeeEntity updatedEmployee);

    public boolean doesEmployeeExistByEmail(String email);

    public EmployeeEntity addNewEmployee(EmployeeDto employeeData);

    public Optional<EmployeeEntity> findByEmail(String email);

    public void removeEmployee(EmployeeEntity employee);

}
