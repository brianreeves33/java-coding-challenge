package com.ibm.fscc.employeeservice.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.ibm.fscc.employeeservice.data.EmployeeEntity;
import com.ibm.fscc.employeeservice.services.EmployeeServiceImpl;
import com.ibm.fscc.employeeservice.shared.EmployeeDto;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/employee")
public class EmployeeController {

	private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	@Autowired
	private Environment env;

	@Autowired
	private EmployeeServiceImpl employeeService;

	@GetMapping(path = "/employees")
	public EmployeeResponse viewAllEmployees() {
		List<EmployeeEntity> listOfEmployees = employeeService.getAllEmployees();

		logger.info("listofEmployees", listOfEmployees.toString());

		return new EmployeeResponse(HttpStatus.OK, "employees: " + listOfEmployees, true);
	}

	@PutMapping(path = "/update-employee")
	public EmployeeResponse updateUser(@RequestBody EmployeeDto userData) {

		Optional<EmployeeEntity> queryResult = employeeService.findByEmail(userData.getEmail());

		if (!queryResult.isPresent()) {
			return new EmployeeResponse(HttpStatus.NOT_FOUND, "User does not exist", false);
		}

		EmployeeEntity updatedEmployee = queryResult.get();

		updatedEmployee.updateFields(userData);

		employeeService.updateEmployee(updatedEmployee);

		return new EmployeeResponse(HttpStatus.OK, "user updated: " + updatedEmployee, true);
	 }

	@PostMapping(path = "/add-employee")
	public EmployeeResponse addNewUser(@RequestBody EmployeeDto employeeData) {

		if (employeeService.doesEmployeeExistByEmail(employeeData.getEmail())) {
			return new EmployeeResponse(HttpStatus.CONFLICT, "User already exists", false);
		}

		EmployeeEntity newUser = employeeService.addNewEmployee(employeeData);

		return new EmployeeResponse(HttpStatus.CREATED, "User added" + newUser.toString(), true);
	}

	@DeleteMapping(path = "/remove-employee")
	public EmployeeResponse removeUser(@RequestBody String email) {

		Optional<EmployeeEntity> employee = employeeService.findByEmail(email);

		if (!employee.isPresent()) {

			return new EmployeeResponse(HttpStatus.BAD_REQUEST, "User with email " + email + " does not exist", false);

		}

		EmployeeEntity deleltedEmployee = employee.get();

		employeeService.removeEmployee(deleltedEmployee);

		return new EmployeeResponse(HttpStatus.OK, "User deleted", true);
	}

	@GetMapping(path = "/status/check")
	public EmployeeResponse status() {
		return new EmployeeResponse(HttpStatus.ACCEPTED, "Working on port " + env.getProperty("server.port"), true);
	}



}