package com.ibm.fscc.kafka.service.impl;

import com.ibm.fscc.kafka.service.ConsumerService;
import org.springframework.stereotype.Component;

@Component
public class ConsumerServiceImpl implements ConsumerService {

    @Override
    public void consume() {

    }
}
