package com.ibm.fscc.kafka.service;

public interface ProducerService {
    public void produce();
}
