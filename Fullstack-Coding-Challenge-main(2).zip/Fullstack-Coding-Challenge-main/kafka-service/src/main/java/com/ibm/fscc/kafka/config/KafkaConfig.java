package com.ibm.fscc.kafka.config;

import org.springframework.context.annotation.Configuration;
import java.util.Properties;

@Configuration
public class KafkaConfig {

    Properties config = new Properties();
    // TODO - implement remaining properties
}
