package com.ibm.fscc.kafka.service.impl;

import com.ibm.fscc.kafka.service.ProducerService;
import org.springframework.stereotype.Component;

@Component
public class ProducerServiceImpl implements ProducerService {
    @Override
    public void produce() {
        //TODO
    }
}
