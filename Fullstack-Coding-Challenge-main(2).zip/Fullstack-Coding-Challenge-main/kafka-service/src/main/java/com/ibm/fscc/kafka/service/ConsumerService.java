package com.ibm.fscc.kafka.service;

public interface ConsumerService {
    public void consume();
}
