package com.ibm.fscc.loginservice.services.login;

import java.util.List;
import java.util.Optional;

import com.ibm.fscc.loginservice.shared.LoginDto;
import com.ibm.fscc.loginservice.data.LoginEntity;;

public interface LoginService {

	public Optional<LoginEntity> getCredentials(String email);

	public boolean doesUserExist(String email);

	public List<LoginEntity> getAllUsers();

	public void createNewUser(LoginDto userInput);

}
