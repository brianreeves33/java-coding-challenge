package com.ibm.fscc.loginservice.repository;

import java.util.Optional;
import org.springframework.data.repository.CrudRepository;

import com.ibm.fscc.loginservice.data.LoginEntity;

public interface LoginRepository extends CrudRepository<LoginEntity, Long> {

    Optional<LoginEntity> findByEmail(String email);

    boolean existsByEmail(String email);
}