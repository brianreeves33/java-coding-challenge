package com.ibm.fscc.loginservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ibm.fscc.loginservice.data.LoginEntity;
import com.ibm.fscc.loginservice.services.login.LoginServiceImpl;
import com.ibm.fscc.loginservice.services.security.LoginSecurityImpl;
import com.ibm.fscc.loginservice.services.security.services.jwt.AuthRequest;
import com.ibm.fscc.loginservice.services.security.services.jwt.service.JwtService;
import com.ibm.fscc.loginservice.shared.LoginDto;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/login")
public class LoginController {

	@Autowired
	private Environment env;

	@Autowired
	private LoginServiceImpl loginService;

	@Autowired
	private LoginSecurityImpl securityService;

	@Autowired
	JwtService jwtService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@PostMapping(path = "/authenticate")
	public LoginResponse submitLogin(@RequestBody LoginDto userInput) {

		AuthRequest authRequest = new AuthRequest(userInput);

		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));

		if (authentication.isAuthenticated()) {
			String webToken = securityService.generateToken(authRequest);

			return new LoginResponse(HttpStatus.ACCEPTED, webToken, true);
		}

		return new LoginResponse(HttpStatus.UNAUTHORIZED, "User Unauthorized", false);

	}

	@PostMapping(path = "/register")
	public LoginResponse registerUser(@RequestBody LoginDto userCredentials) {

		if (loginService.doesUserExist(userCredentials.getEmail()))
			return new LoginResponse(HttpStatus.CONFLICT, "User Already Exists", false);

		loginService.createNewUser(userCredentials);

		return new LoginResponse(HttpStatus.CREATED, "user created: " + userCredentials.getEmail(), true);
	}

	@GetMapping(path = "/view-all")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public LoginResponse getAllUsers() {
		List<LoginEntity> userList = loginService.getAllUsers();

		return new LoginResponse(HttpStatus.OK, "users: " + userList, true);
	}

	@GetMapping(path = "/user-login")
	public LoginResponse login(@RequestBody LoginDto userCredentials){
		Optional<LoginEntity> login = loginService.getCredentials(userCredentials.getEmail());

		System.out.println("LOGIN: " + login);

		if(!login.isPresent()){
			return new LoginResponse(HttpStatus.UNAUTHORIZED, "User does not exist", false);
		} else {
			AuthRequest authRequest = new AuthRequest(userCredentials);
		
			String webToken = securityService.generateToken(authRequest);

			return new LoginResponse(HttpStatus.ACCEPTED, webToken, true);
		}

		

		

	}

	@GetMapping(path = "/status/check")
	public LoginResponse status() {
		return new LoginResponse(HttpStatus.ACCEPTED, "Working on port " + env.getProperty("server.port"), true);
	}

}
