package com.ibm.fscc.loginservice.services.security;

import com.ibm.fscc.loginservice.services.security.services.jwt.AuthRequest;

public interface LoginSecurity {

    public String encryptPassword(String password);

    public String generateToken(AuthRequest authRequest);

}
