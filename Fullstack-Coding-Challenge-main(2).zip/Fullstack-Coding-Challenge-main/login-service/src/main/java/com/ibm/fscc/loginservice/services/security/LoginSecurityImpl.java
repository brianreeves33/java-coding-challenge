package com.ibm.fscc.loginservice.services.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.ibm.fscc.loginservice.services.security.services.jwt.AuthRequest;
import com.ibm.fscc.loginservice.services.security.services.jwt.service.JwtService;

@Service
public class LoginSecurityImpl implements LoginSecurity {

    @Autowired
    private BCryptPasswordEncoder encoder;

    @Autowired
    private JwtService jwtService;

    @Override
    public String encryptPassword(String password) {

        return encoder.encode(password);
    }

    public boolean matches(String raw, String encoded) {
        return encoder.matches(raw, encoded);
    }

    @Override
    public String generateToken(AuthRequest authRequest) {
        return jwtService.generateToken(authRequest.getUsername());
    }

}
