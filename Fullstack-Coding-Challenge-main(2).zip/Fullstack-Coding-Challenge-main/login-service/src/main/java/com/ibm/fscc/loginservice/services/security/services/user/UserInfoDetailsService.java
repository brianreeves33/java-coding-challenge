package com.ibm.fscc.loginservice.services.security.services.user;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.ibm.fscc.loginservice.data.LoginEntity;
import com.ibm.fscc.loginservice.services.login.LoginServiceImpl;

@Component
public class UserInfoDetailsService implements UserDetailsService {

    @Autowired
    private LoginServiceImpl loginService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        Optional<LoginEntity> loginEntity = loginService.getCredentials(username);

        return loginEntity.map(UserInfoDetails::new)
                .orElseThrow(() -> new UsernameNotFoundException("user not found" + username));

    }

}
