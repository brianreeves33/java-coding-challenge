package com.ibm.fscc.loginservice.services.login;

import java.util.Optional;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.fscc.loginservice.shared.LoginDto;
import com.ibm.fscc.loginservice.data.LoginEntity;

import com.ibm.fscc.loginservice.repository.LoginRepository;
import com.ibm.fscc.loginservice.services.security.LoginSecurityImpl;

@Service
public class LoginServiceImpl implements LoginService {

    @Autowired
    private LoginRepository loginRepository;

    @Autowired
    private LoginSecurityImpl loginSecurity;

    //TODO:
    @Override
    public boolean doesUserExist(String email) {
        return loginRepository.existsByEmail(email);
    }

    @Override
    public Optional<LoginEntity> getCredentials(String email) {

        return loginRepository.findByEmail(email);

    }

    @Override
    public void createNewUser(LoginDto userInput) {

        String encryptedPwd = loginSecurity.encryptPassword(userInput.getPassword());

        userInput.setPassword(encryptedPwd);

        LoginEntity newUserEntity = new LoginEntity(userInput);

        loginRepository.save(newUserEntity);

    }

    @Override
    public List<LoginEntity> getAllUsers() {
        return (List<LoginEntity>) loginRepository.findAll();
    }

}
