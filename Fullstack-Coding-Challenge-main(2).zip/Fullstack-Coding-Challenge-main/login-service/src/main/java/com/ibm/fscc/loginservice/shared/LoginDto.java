package com.ibm.fscc.loginservice.shared;

import com.ibm.fscc.loginservice.data.LoginEntity;

public class LoginDto {

    private String email;
    private String password;
    private String roles;

    public LoginDto() {
    }

    public LoginDto(String email, String password, String roles) {

        this.email = email;
        this.password = password;
        this.roles = roles;
    }

    public LoginDto(LoginEntity loginEntity) {

        this.email = loginEntity.getEmail();
        this.password = loginEntity.getPassword();
        this.roles = loginEntity.getRoles();
    }

    public String getRoles() {
        return this.roles;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
