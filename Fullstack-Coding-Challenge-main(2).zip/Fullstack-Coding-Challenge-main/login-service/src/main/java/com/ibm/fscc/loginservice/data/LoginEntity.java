package com.ibm.fscc.loginservice.data;

import com.ibm.fscc.loginservice.shared.LoginDto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "login")
public class LoginEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String email; // primary key
	private String password; // encrypted
	private String roles;

	public LoginEntity() {
	}

	public LoginEntity(LoginDto loginDto) {
		this.email = loginDto.getEmail();
		this.password = loginDto.getPassword();
		this.roles = loginDto.getRoles();
	}

	public LoginEntity(String email, String password, String name, String roles) {
		this.email = email;
		this.password = password;
		this.roles = roles;

	}


	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
