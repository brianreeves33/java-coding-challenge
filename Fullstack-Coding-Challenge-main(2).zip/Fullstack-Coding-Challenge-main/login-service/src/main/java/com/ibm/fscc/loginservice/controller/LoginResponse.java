package com.ibm.fscc.loginservice.controller;

import org.springframework.http.HttpStatusCode;

public class LoginResponse {

    private String message;
    private boolean ok;
    private HttpStatusCode response;

    public LoginResponse(HttpStatusCode response, String message, boolean ok) {
        this.message = message;
        this.response = response;
        this.ok = ok;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public HttpStatusCode getResponse() {
        return response;
    }

    public void setResponse(HttpStatusCode response) {
        this.response = response;
    }

}
