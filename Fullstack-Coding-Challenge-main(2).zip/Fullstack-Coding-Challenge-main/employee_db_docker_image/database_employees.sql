DROP TABLE IF EXISTS employee;
create table employee (
    id INT NOT NULL AUTO_INCREMENT,
    user_id VARCHAR(100) UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    address VARCHAR(50) NOT NULL,
    state VARCHAR(50) NOT NULL,
    zip VARCHAR(50) NOT NULL,
    cell_phone VARCHAR(50) NOT NULL,
    home_phone VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    PRIMARY kEY(id),
    UNIQUE(email)
);