DROP TABLE IF EXISTS login;
CREATE TABLE login (
    id INT NOT NULL AUTO_INCREMENT,
    email Varchar(50) NOT NULL UNIQUE,
    password Varchar(500) NOT NULL,
    roles Varchar(50) NOT NULL,
    PRIMARY KEY(id)
);